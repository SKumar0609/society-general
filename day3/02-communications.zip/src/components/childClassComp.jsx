import { Component } from "react";

class ChildClassComp extends Component {
    state = {
        tempfname : "",
        templname : ""
    }
  render() {
    /*  
    let power = this.props.power;
    let version = this.props.version; 
    */
   let {power, version, powerChangeHandler, setFirstName, setLastName} = this.props;

    return <div style={{ border: "2px solid red", padding: "10px", margin: "10px" }}>
                <h3>Child Component</h3>
                <hr />
                <h4>Power sent from parent : { power }</h4>
                <h4>Version sent from parent : { version }</h4>
                <br />
                First Name : <input type="text" onChange={(evt)=> this.setState({ tempfname : evt.target.value })} />
                <br />
                Last Name : <input type="text" onChange={(evt)=> this.setState({ templname : evt.target.value })} />
                <br />
                <button onClick={ ()=> {
                    setFirstName(this.state.tempfname);
                    setLastName(this.state.templname);
                } }>Change Names</button>
                <br />
                <button onClick={ ()=> powerChangeHandler(10) }>Change Power</button>
            </div>
  }
}

export default ChildClassComp;
