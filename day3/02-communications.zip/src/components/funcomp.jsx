import { useState } from "react";
import ChildFunComp from "./childFunComp";

let FunComp = () => {
    let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    
    return <div style={ {border : "2px solid darkseagreen", padding : "10px", margin : "10px"} }>
                <h2>Function Component</h2>
                Power : <input value={power} type="range" onChange={(evt)=> setPower(Number(evt.target.value))} />
                <br />
                Version : <input value={version} type="range" onChange={(evt)=> setVersion(Number(evt.target.value))} />
                <hr />
                <ChildFunComp setPower={setPower} setVersion={setVersion} version={version} power={power}/>
            </div>
}

export default FunComp;