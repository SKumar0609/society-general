import { Component } from "react";
import ChildClassComp from "./childClassComp";

class ClassComp extends Component {
    state = {
        power : 0,
        version : 0,
        firstname : "",
        lastname : ""
    }
    powerChangeHandler = (arg)=>{
        // alert("power change handler was called");
        this.setState({power : arg})
    }
    setFirstName = (arg) => {
        this.setState({ firstname : arg  })
    }
    setLastName = (arg) => {
        this.setState({ lastname : arg  })
    }
  render() {
    return <div style={{ border: "2px solid red", padding: "10px", margin: "10px" }}>
                <h2>Class Component</h2>
                <h3>Power : { this.state.power }</h3>
                <h3>Full Name : { this.state.firstname+" "+this.state.lastname }</h3>
                <hr /> 
                <input onChange={(evt)=> this.setState({ power : Number(evt.target.value) })} type="range" />
                <br />
                <input onChange={(evt)=> this.setState({ version : Number(evt.target.value) })} type="range" />
                {/* <ChildClassComp version={ this.state.version } power={ this.state.power }/> */}
                <ChildClassComp setFirstName={this.setFirstName} setLastName={this.setLastName} powerChangeHandler={this.powerChangeHandler} {...this.state} />
            </div>
  }
}

export default ClassComp;
