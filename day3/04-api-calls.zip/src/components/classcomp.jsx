import { Component } from "react";
import axios from "axios";

class ClassComp extends Component {
    state = {
        users : []
     }
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=1")
        .then((res) => {
            console.log(res);
            this.setState({ users : res.data.data });;
        } )
        .catch(err => console.log("Error ", err))
    }
    render() {
        return <div style={{ border: "2px solid red", padding: "10px", margin: "10px" }}>
                    <h2>Class Component</h2>
                    <ul>
                        { this.state.users.map( val => <li key={val.id} >{val.first_name+" "+val.last_name}</li> ) }
                    </ul> 
               </div>
    }
}
export default ClassComp;
