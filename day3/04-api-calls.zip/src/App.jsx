import ClassComp from "./components/classcomp";
import FunComp from "./components/funcomp";

let App = ()=>{
  return <div>
          <h1>API Calls</h1>
          <ClassComp/>
          <FunComp/>
        </div>


}
export default App;