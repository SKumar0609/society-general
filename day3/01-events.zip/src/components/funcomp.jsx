import { useRef, useState } from "react";

let FunComp = () => {
    let [power, setPower] = useState(0);
    let ipRef = useRef();
    let clickHandler = () => {
        setPower(Number(ipRef.current.value))
    }
    return <div style={ {border : "2px solid darkseagreen", padding : "10px", margin : "10px"} }>
                <h2>Function Component</h2>
                <hr />
                <h3>Power : { power }</h3>
                <button onClick={ ()=> setPower(power+1) }>Increase Power</button>
                <br />
                <input onChange={ (evt) => setPower(Number(evt.target.value))} type="range" />
                <br />
                <input ref={ ipRef } type="number" />
                <button onClick={ clickHandler }>Increase Power</button>
            </div>
}

export default FunComp;