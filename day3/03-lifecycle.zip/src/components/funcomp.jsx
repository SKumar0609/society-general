import { useEffect } from "react";

let FunComp = ({ version, rating }) => {
   useEffect(function(){
    // will be called when the component is mounted
    console.log("FunComp was mounted");
    return function(){
        // will be called when the component is unmounted
        console.log("FunComp was unmounted");
    }
   },[]);

   useEffect(function(){
    // will be called when the component is mounted
    console.log("FunComp received a new version", version);
    console.log("FunComp received a new rating", rating);
   });


    return <div style={ {border : "2px solid darkseagreen", padding : "10px", margin : "10px"} }>
                <h2>Function Component</h2>
                <h3>Parent Version : { version }</h3>
                <h3>Parent Rating : { rating }</h3>
            </div>
}

export default FunComp;