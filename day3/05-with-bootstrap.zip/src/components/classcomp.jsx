import { Component } from "react";
import axios from "axios";
import "../styles/mystyle.css";

class ClassComp extends Component {
    state = {
        users : []
     }
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=1")
        .then((res) => {
            console.log(res);
            this.setState({ users : res.data.data });;
        } )
        .catch(err => console.log("Error ", err))
    }
    render() {
        return <div style={{ border: "2px solid red", padding: "10px", margin: "10px" }}>
                    <h2  className="display-4 box">Class Component</h2>
                    <div>
                        { this.state.users.map( val => <div className="card" style={ {width : "180px", margin:"20px"} } key={val.id} >
                            <img style={ {maxWidth : "180px"} } src={val.avatar} className="card-img-top" alt={val.first_name+" "+val.last_name+"'s profile"}/>
                            <div className="card-body">
                                <p className="card-text">{val.first_name+" "+val.last_name}</p>
                                <a href={"mailto:"+val.email}>eMail</a>
                            </div>
                        </div> ) }
                    </div> 
               </div>
    }
}
export default ClassComp;
