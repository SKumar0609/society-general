import axios from "axios";
import { useEffect, useState } from "react";

let FunComp = () => {
   let [users, setUsers] = useState([]);
   useEffect(function(){
    axios.get("https://reqres.in/api/users?page=2")
    .then(res => setUsers(res.data.data))
    .catch(err => console.log("Error ", err))
   },[]);
    return <div style={ {border : "2px solid darkseagreen", padding : "10px", margin : "10px"} }>
                <h2  className="display-4">Function Component</h2>
                <ul>
                    { users.map( val => <li key={val.id} >{val.first_name+" "+val.last_name}</li> ) }
                </ul> 
           </div>
}

export default FunComp;