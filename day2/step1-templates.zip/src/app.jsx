/* 
function App(){
    return <h1>Welcome to your life</h1>
};
export { App } 
*/

// commonjs / nodejs import
// const { Component } = require("react");

// es6 import
import { Component } from "react";
import { Header } from "./components/header";
import { TitleTag } from "./components/title";
import { MainBox } from "./components/main";
import { Footer } from "./components/footer";

class App extends Component{
    render(){
        return <div>
                <Header/>
                <TitleTag/>
                <MainBox/>
                <Footer/>
               </div>
    }
};

export default App