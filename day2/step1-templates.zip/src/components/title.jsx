import { Component } from "react";

export class TitleTag extends Component{
    render(){
        return <div style={ {height : '50px', outline:'1px solid red' } }>
                    Slogan & Logo comes here
               </div>
    }
}