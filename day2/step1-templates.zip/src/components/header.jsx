import { Component } from "react";

export class Header extends Component{
    render(){
        return <div style={ {backgroundColor : 'black' } }>
                <div  style={ { marginLeft : '150px', color : 'whitesmoke'} }>Social media icons</div>
               </div>
    }
}