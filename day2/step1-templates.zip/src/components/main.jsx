import { Component } from "react";

export class MainBox extends Component{
    render(){
        return <div style={ {height : '400px', backgroundColor : 'papayawhip', outline:'1px solid red', textAlign : 'center', lineHeight : '400px' } }>
                   Main box comes here
               </div>
    }
}