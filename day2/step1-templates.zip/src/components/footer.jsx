import { Component } from "react";

export class Footer extends Component{
    render(){
        return <div style={ {color:"whitesmoke", backgroundColor : 'black', height : "150px" } }>
                Footer Component
               </div>
    }
}