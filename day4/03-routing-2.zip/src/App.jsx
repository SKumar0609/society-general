import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home";
import BatmanComp from "./components/batman";
import CyborgComp from "./components/cyborg";
import FlashComp from "./components/flash";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen";
import NotFound from "./components/notfound";
import "./styles/mystyle.css";

let App = ()=>{
  return <div className="container">
          <BrowserRouter>
            {/* Routing code comes here */}
            <ul className="nav">
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/"}>Home</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/batman"}>Batman</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/superman"}>Superman</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/cyborg"}>Cyborg</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/flash"}>Flash</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/wonderwomen"}>Wonder Women</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/aquaman"}>Aquaman</NavLink></li>
              <li className="nav-item"><NavLink className={ ({isActive}) => isActive ? 'nav-link box' : 'nav-link' } to={"/hulk"}>Hulk</NavLink></li>
            </ul>
            <Routes>
              <Route path="/" element={<HomeComp/>}/>
              <Route path="/batman" element={<BatmanComp/>}/>
              <Route path="/cyborg" element={<CyborgComp/>}/>
              <Route path="/flash" element={<FlashComp/>}/>
              <Route path="/superman" element={<SupermanComp/>}/>
              <Route path="/wonderwomen" element={<WonderWomenComp/>}/>
              <Route path="/aquaman" element={<BatmanComp/>}/>
              <Route path="*" element={<NotFound/>}/>
            </Routes>
          </BrowserRouter>
        </div>
}
export default App;