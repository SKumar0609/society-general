let BatmanComp = () => {
    return <div>
                <h1>Batman Component</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, tempora cumque eligendi fugit ullam ducimus facere vel voluptates perferendis eius, facilis ipsum animi officiis. Mollitia amet non iure dolore fuga!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto atque quaerat harum aliquam deleniti eum. Harum sed facere sunt non veritatis est doloremque ducimus, iusto, commodi vitae beatae accusamus porro?
                </p>
            </div>
};

export default BatmanComp;