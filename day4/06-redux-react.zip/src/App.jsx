import { Provider } from "react-redux";
import HeroComp from "./components/hero";
import store from "./redux/store";
import SideKick from "./components/sidekick";

let App = ()=>{
  return <div className="container">
          <Provider store={ store }>
            <HeroComp/>
            <SideKick/>
          </Provider>
        </div>
}
export default App;