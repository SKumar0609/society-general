import addHero from "./hero/actions/hero.actions";

export { addHero };