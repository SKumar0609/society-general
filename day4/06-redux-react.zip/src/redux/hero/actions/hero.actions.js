import { ADD_HERO } from "../types/hero.type"

const addHero = () => {
    return {
        type : ADD_HERO
    }
};

export default addHero;