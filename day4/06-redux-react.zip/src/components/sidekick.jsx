import { useSelector } from "react-redux";

let SideKick = ()=>{
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );
    return <div>
                <h1>Sidekick Component</h1>
                <h2>Number of Heroes : {numberOfHeroes}</h2>
           </div>
};

export default SideKick;