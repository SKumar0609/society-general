import { useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux"

let HeroComp = ()=>{
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );
    const dispatch = useDispatch();

    return <div>
                <h1>Avenger's Component</h1>
                <h2>Number of Heroes : {numberOfHeroes}</h2>
                <button className="btn btn-primary" onClick={()=> dispatch(addHero())} >Add Hero</button>
           </div>
};

export default HeroComp;