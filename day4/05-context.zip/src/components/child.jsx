import { useContext } from "react";
import { FamilyContext } from "../contexts/familyContext";

let ChildComp = () => {
    let val = useContext(FamilyContext);
    return <div style={ {border : "2px solid red", padding:"10px", margin:"10px"} }>
                <h1>Child Component</h1>
                <hr />
                {/* <FamilyContext.Consumer>{(val)=><h2>{val}</h2>}</FamilyContext.Consumer> */}
                <h2>Power is { val.power }</h2>
                <h2>Version is { val.version }</h2>
           </div>
};

export default ChildComp;