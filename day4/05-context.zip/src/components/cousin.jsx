import { useContext } from "react";
import { FamilyContext } from "../contexts/familyContext";
import { MessageContext } from "../contexts/messageContext";

let CousinComp = () => {
    let val = useContext(FamilyContext);
    let msg = useContext(MessageContext);
    return <div style={ {border : "2px solid red", padding:"10px", margin:"10px"} }>
                <h1>Cousin Component</h1>
                <hr />
                <h2>Power is { val.power }</h2>
                <h2>Version is { val.version }</h2>
                <h2>Message is { msg }</h2>
           </div>
};

export default CousinComp;