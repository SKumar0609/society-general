import { useState } from "react";
import ParentComp from "./parent";
import { FamilyContext } from "../contexts/familyContext";
import CousinComp from "./cousin";
import { MessageContext } from "../contexts/messageContext";

let GrandComp = () => {
    let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    let [message, setMessage] = useState("default");
    return <div style={ {border : "2px solid red", padding:"10px", margin:"10px"} }>
                <h1>Grand Parent Component ~ Power is {power} ~ Version is { version }</h1>
                <h2>Message is : { message }</h2>
                <input type="range" onChange={(evt)=> setPower(Number(evt.target.value))} />
                <input type="range" onChange={(evt)=> setVersion(Number(evt.target.value))} />
                <input type="text" onChange={(evt)=> setMessage(evt.target.value)} />
                <hr />
                <FamilyContext.Provider value={{ power, version }}>
                    <ParentComp/>
                    <MessageContext.Provider value={message}>
                        <CousinComp/>
                    </MessageContext.Provider>
                </FamilyContext.Provider>
           </div>
};

export default GrandComp;