import React from "react";

export let MessageContext = React.createContext();
