import GrandComp from "./components/grand";

let App = ()=>{
  return <div className="container">
          <GrandComp/>
        </div>
}
export default App;