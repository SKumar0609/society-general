let HomeComp = () => {
    return <div>
                <h1>Home Component</h1>
           </div>
};
export default HomeComp;