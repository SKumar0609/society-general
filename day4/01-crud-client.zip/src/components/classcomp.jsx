import { Component } from "react";
import axios from "axios";
import "../styles/mystyle.css";

class ClassComp extends Component {
    state = {
        users : []
     }
    componentDidMount(){
        axios.get("http://localhost:5050/")
        .then((res) => {
            // console.log(res.data);
            this.setState({ users : res.data });;
        } )
        .catch(err => console.log("Error ", err))
    }
    render() {
        return <div style={{ border: "2px solid red", padding: "10px", margin: "10px" }}>
                    <h2  className="display-4 box">Class Component</h2>
                    <div>
                        { this.state.users.map( val => <div className="card" style={ { margin:"20px"} } key={val._id} >
                            <div className="card-body">
                            <h5 className="card-title">{val.title}</h5>
                                <p className="card-text">{val.firstname+" "+val.lastname}</p>
                            </div>
                        </div> ) }
                    </div> 
                    <hr />
                    <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">Sl#</th>
                        <th scope="col">Title</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        { this.state.users.map((val, idx)=>{
                            return <tr key={val._id}>
                                    <td>{idx+1}</td>
                                    <td>{ val.title }</td>
                                    <td>{ val.firstname }</td>
                                    <td>{ val.lastname }</td>
                                </tr>
                        })}
                    </tbody>
                    </table>
               </div>
    }
}
export default ClassComp;
