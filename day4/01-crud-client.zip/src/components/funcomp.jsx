import axios from "axios";
import { useEffect, useState } from "react";

//=======================================
let FunComp = () => {
   let [users, setUsers] = useState([]);
   let [show, setShow] = useState(false);
   let [nuser, setNUser] = useState({ title : "", firstname : "", lastname : ""})
   let [euser, setEUser] = useState({title : "", firstname : "", lastname : ""})
   useEffect(function(){
        reload()
   },[]);
//=======================================
   let reload = () =>{ 
    console.log("reload was called");
    axios.get("http://localhost:5050/")
    .then(res => setUsers(res.data))
    .catch(err => console.log("Error ", err));
   }
   //=======================================
   let sendUserInfo = ()=>{
    axios.post("http://localhost:5050/",nuser)
    .then(res => {
        reload();
        setNUser({ title : "", firstname : "", lastname : ""})
        console.log(res.data);
    })
    .catch(err => console.log("Error ", err))
   }
   //=======================================
   let editUser = (evt)=>{
    axios.get("http://localhost:5050/edit/"+evt.target.getAttribute("data-info"))
    .then(res =>  {
        setEUser(res.data);
        setShow(!show);
    })
    .catch(error => console.log("Error",error));
   }
   let deleteUser = (evt)=>{
       // alert(evt.target.getAttribute("data-info"));
       axios.delete("http://localhost:5050/delete/"+evt.target.getAttribute("data-info"))
       .then(res => {
        reload();
        console.log(res.data);
    })
    .catch(err => console.log("Error ", err));
   }
   //=======================================
   let updateUserInfo = () =>{
    axios.post("http://localhost:5050/edit/"+euser._id, euser)
    .then(res => {
        reload();
        setShow(!show);
        setEUser({ title : "", firstname : "", lastname : ""})
        console.log(res.data);
    })
    .catch(err => console.log("Error ", err))
   }
   //=======================================
    return <div style={ {border : "2px solid darkseagreen", padding : "10px", margin : "10px"} }>
                <h2  className="display-4">Function Component</h2>
                <hr />
                {/* New User Form */}
                {
                    !show &&                 <div id="newUser">
                    <h2>Add New User</h2>
                    <div className="mb-3">
                    <label htmlFor="usertitle" className="form-label">User Title</label>
                    <input value={nuser.title} onChange={(evt) => setNUser({...nuser, title : evt.target.value })} type="text" className="form-control" id="usertitle" />
                    </div>
    
                    <div className="mb-3">
                    <label htmlFor="fname" className="form-label">First Name</label>
                    <input value={nuser.firstname} type="text" onChange={(evt) => setNUser({...nuser, firstname : evt.target.value })}  className="form-control" id="fname" />
                    </div>
    
                    <div className="mb-3">
                    <label htmlFor="lname" className="form-label">Last Name</label>
                    <input value={nuser.lastname} type="text" onChange={(evt) => setNUser({...nuser, lastname : evt.target.value })}  className="form-control" id="lname" />
                    </div>
    
                    <div className="mb-3">
                    <button onClick={ sendUserInfo } className="btn btn-primary"> Add User </button>
                    </div>
                    </div>
                }
                {/* Edit User Form */}
                { show && <div id="editUser">
                <h2>Edit User</h2>
                <div className="mb-3">
                <label htmlFor="usertitle" className="form-label">User Title</label>
                <input value={euser.title} onChange={(evt) => setEUser({...euser, title : evt.target.value })} type="text" className="form-control" id="usertitle" />
                </div>

                <div className="mb-3">
                <label htmlFor="fname" className="form-label">First Name</label>
                <input value={euser.firstname} type="text" onChange={(evt) => setEUser({...euser, firstname : evt.target.value })}  className="form-control" id="fname" />
                </div>

                <div className="mb-3">
                <label htmlFor="lname" className="form-label">Last Name</label>
                <input value={euser.lastname} type="text" onChange={(evt) => setEUser({...euser, lastname : evt.target.value })}  className="form-control" id="lname" />
                </div>

                <div className="mb-3">
                <button onClick={ updateUserInfo } className="btn btn-primary"> Update User </button>
                </div>
                </div>}
                <hr />
                <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">Sl#</th>
                        <th scope="col">Title</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {  users.map((val, idx)=>{
                            return <tr key={val._id}>
                                    <td>{idx+1}</td>
                                    <td>{ val.title }</td>
                                    <td>{ val.firstname }</td>
                                    <td>{ val.lastname }</td>
                                    <td><button onClick={editUser} data-info={val._id} className="btn btn-warning">Edit</button></td>
                                    <td><button onClick={deleteUser} data-info={val._id} className="btn btn-danger">Delete</button></td>
                                </tr>
                        })}
                    </tbody>
                    </table>
           </div>
}

export default FunComp;