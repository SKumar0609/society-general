import ClassComp from "./components/classcomp";
import FunComp from "./components/funcomp";

let App = ()=>{
  return <div className="container">
          <h1 className="display-3">API Calls</h1>
          {/* <ClassComp/> */}
          <FunComp/>
        </div>


}
export default App;